
clear all;
warning('off','all');
close all;
clc;



num_runs= 30; %Number of runs
pop=50; %Population 



%% Gray-level values
MinValue = 1;
MaxValue = 256;


num_thr = [4,6,8,10];
ThNum = numel(num_thr);

names={'t386','t399','t400','t401','t420','t731','t752','t770','t771'};%,'t2763','t1356','t1465','t1495','t1535','t1681'};

MR_Images = numel(names); 
 
for Algorithm=2 
    fil=1;
for I = 1:MR_Images  %%   goruntu sayısı
    fname=strcat(names{1,I},'.mat');
    
    nut=cell2str(names{1,I});
%      nut = nut(1:(end-1));
%     fprintf(' \n\n----- Image = %s -----\n', nut)

    load(fname);
    Im=uint8(cjdata.image);
    
    for thr = num_thr
        T=num2str(thr);
%         fprintf('Threshold = %s\n', T)
        levels = thr;
        itermax = 3333;
        TempVSolu = 0;

        %% Result Vector
        BestFitStore = []; % Best Fitness vector
        BestSolStore = []; % Best Solution vector
        PSNRvect = [];
        FSIMvect = [];
        SSIMvect = [];
        UIQIvect = [];
        QILVvect = [];
        HPSIvect = [];
        TimeVect = [];
    
for k=1:num_runs
    switch Algorithm
%     case 1
%             Alg_name = 'HHO_ALT'; %Algorithm name
%             [BestFitt, BestSolu, metrics, time, Iout] = HHOalt(pop, itermax, MinValue, MaxValue,levels+1, Im);
    case 2
            Alg_name = 'CJADE';
             [BestFitt, BestSolu, metrics, time, Iout] = CJADE(pop, itermax, MinValue, MaxValue,levels+1, Im);
%     case 3
%             Alg_name = 'ALO';
%              [BestFitt,Convergence_curve,BestSolu, metrics, time, Iout]=alo_seg(pop,levels+1,C,MinValue,MaxValue,Im);
%     case 4       
%             Alg_name = 'DA';
%             [BestFitt,cg_curve,BestSolu,metrics, time, Iout]=da_seg(pop,levels+1, itermax,MinValue,MaxValue,Im);
%     case 5
%             Alg_name = 'HHO_ORG';
%             [BestFitt,BestSolu,metrics,time, Iout]=HHO_normal(pop,itermax,MinValue,MaxValue,levels+1,Im);
%     case 6
%             Alg_name = 'LSHADE';
%             [BestFitt, converH, BestSolu, metrics, time, Iout] = lshade(pop, levels+1, itermax, MinValue, MaxValue, Im);
%     case 7
%             Alg_name = 'MFO';
%             [BestFitt,Convergence_curve,BestSolu,metrics, time, Iout]=mfo_seg(pop,levels+1,itermax,MinValue,MaxValue,Im);
%     case 8
%             Alg_name = 'WOA';
%             [BestFitt,Convergence_curve,BestSolu, metrics, time, Iout]=woa_seg(pop,levels+1,itermax,MinValue,MaxValue,Im);
%     case 5
%             Alg_name = 'DOBES';
%             [BestFitt,Convergence_curve,BestSolu, metrics, time, Iout]=DOBES(pop,levels+1,itermax,MinValue,MaxValue,Im);
%     case 2
%             Alg_name = 'ACO';
%             [BestFitt,Convergence_curve,BestSolu, metrics, time, Iout]=acor(pop,levels+1,itermax,MinValue,MaxValue,Im);
%     case 3
%             Alg_name = 'mRSA';
%            [BestFitt,Convergence_curve,BestSolu, metrics, time, Iout]=mRSA(pop,levels+1,itermax,MinValue,MaxValue,Im);
%     case 4
%             Alg_name = 'ZOA';
%            [BestFitt,Convergence_curve,BestSolu, metrics, time, Iout]=ZOA(pop,levels+1,itermax,MinValue,MaxValue,Im);

    end
%              [Best_F,Conv,bsf_solution,metrics, time, Iout]=RSA(N,dim,MaxIt,LB,UB,Im)
%% File for results
date = datestr(datetime('now','Format','dd-MM-yyyy'));
namexc = strcat(Alg_name,'_Threshold_' , T , '_Date_',date(1:11),'.xlsx');
titles = {'BstFit','Bstsol','PSNR','SSIM','FSIM','UIQI','QILV','HPSI','Time'};
%xlswrite(namexc,titles,1,'A1')
% fprintf("It: %d --- %s\n", k, namexc);
%show figs  
flagx = 1;
   
            if isinf(BestFitt)
                continue        
            end

            BestFitStore = [BestFitStore, BestFitt];%concatenation of vector by column
            BestSolu = BestSolu(1:levels);%strip data for CE detail
            BestSolStore = [BestSolStore, mat2str(BestSolu)];

            PSNRvect = [PSNRvect, metrics(1)];  
            SSIMvect = [SSIMvect, metrics(2)];
            FSIMvect = [FSIMvect, metrics(3)];
            UIQIvect = [UIQIvect, metrics(4)];  
            QILVvect = [QILVvect, metrics(5)];
            HPSIvect = [HPSIvect, metrics(6)];

            TimeVect = [TimeVect, time];
            TempVSolu = TempVSolu + BestSolu;
            
end  % runs   
        

        %% Average solution
        TempVSolu=TempVSolu/num_runs;
        [BestFitnexx, posx]=min(BestFitStore);

        dataBest{fil, 1} = BestFitnexx;
        dataBest{fil, 2} = Strxtract(BestSolStore,posx);
        dataBest{fil, 3} = mean(PSNRvect);
        mean(PSNRvect);
        dataBest{fil, 4} = mean(SSIMvect);
        mean(SSIMvect);
        dataBest{fil, 5} = mean(FSIMvect);
        dataBest{fil, 6} = mean(UIQIvect);    
        dataBest{fil, 7} = mean(QILVvect);   
        dataBest{fil, 8} = mean(HPSIvect);
        dataBest{fil, 9} = mean(TimeVect);

    %---------------------------------------------------*

        dataBest{fil, 10} = BestFitStore;
        dataBest{fil, 11} = PSNRvect;
        dataBest{fil, 12} = SSIMvect;   
        dataBest{fil, 13} = FSIMvect;
        dataBest{fil, 14} = UIQIvect;    
        dataBest{fil, 15} = QILVvect;  
        dataBest{fil, 16} = HPSIvect;  
        dataBest{fil, 17} = TimeVect; 

        fil = fil+1; 

        
    end% th
    aname2=strcat('Image_', nut, '_', Alg_name, '_.mat');  
    save(aname2,'dataBest');
end % images

end


